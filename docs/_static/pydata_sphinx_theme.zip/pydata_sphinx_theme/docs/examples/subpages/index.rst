Section to show off pages with many sub-pages
=============================================

To create an additional level of nesting in the sidebar, construct a
nested ``toctree``:

.. toctree::

    subpage1
    subpage2
    subsubpages/index
