# Gallery of sites using this theme

This is a gallery of documentation built on top of the `pydata-sphinx-theme`.
If you'd like to add your documentation to this list, simply add an entry to [this gallery.yaml file](https://github.com/pydata/pydata-sphinx-theme/blob/main/docs/_static/gallery.yaml) and open a Pull Request to add it.

```{gallery-grid} ../_static/gallery.yaml
:grid-columns: "1 2 2 3"

```
