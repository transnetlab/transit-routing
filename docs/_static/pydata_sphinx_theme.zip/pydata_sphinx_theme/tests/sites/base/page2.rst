:html_theme.sidebar_secondary.remove: true

Page 2
======
