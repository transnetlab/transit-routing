# Contributing to this theme

Contributions are very welcome! Installing the development version, building
the example docs and developing the css/js of the theme, etc, is explained in
more detail in the contributing section of the documentation:

- [Community and contribution guide source](docs/community/index.md)
- [Community and contribution guide rendered docs](https://pydata-sphinx-theme.readthedocs.io/en/latest/community/index.html)
